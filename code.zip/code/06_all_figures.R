library(arrow)
library(tidyverse)
library(vegan)
library(FactoMineR)
library(factoextra)
library(cluster)
library(ggrepel)
library(patchwork)

# 创建图片输出目录
dir.create("../figs", showWarnings = FALSE)

# ==========================
# 读取数据
# ==========================
df <- read_parquet("../analysis_df.parquet") %>%
  mutate(log_chars = log(n_chars))

E <- readRDS("../embed_matrix.rds")
E <- E[df$doc_id, , drop = FALSE]

meta_cols <- c("doc_id","language","lang_code","stage","concept","query",
               "n_chars","n_sections","pageid","revid","log_chars")
feat_cols <- setdiff(names(df), meta_cols)

# ==========================
# 1. 长度分布箱线图
# ==========================
p_len <- ggplot(df, aes(x = language, y = n_chars, fill = language)) +
  geom_boxplot(outlier.alpha = 0.3) +
  scale_y_log10() +
  theme_minimal(base_size = 14) +
  labs(title = "Text length by language", y = "Characters (log10)", x = "") +
  theme(legend.position = "none")

ggsave("../figs/fig_length_boxplot.png", p_len, width = 8, height = 5, dpi = 300)

# ==========================
# 2. 特征矩阵与距离
# ==========================
X <- df %>%
  select(all_of(feat_cols)) %>%
  mutate(across(everything(), ~ replace_na(., 0))) %>%
  scale()

D <- dist(X, method = "euclidean")

# 语言级平均
lang_mean <- df %>%
  group_by(language) %>%
  summarise(across(all_of(feat_cols), mean, na.rm = TRUE)) %>%
  column_to_rownames("language") %>%
  scale()

D_lang <- dist(lang_mean, method = "euclidean")

# ==========================
# 3. 语言间距离热图
# ==========================
D_mat <- as.matrix(D_lang)
D_df <- as.data.frame(as.table(D_mat))
names(D_df) <- c("lang1", "lang2", "distance")

p_heat <- ggplot(D_df, aes(lang1, lang2, fill = distance)) +
  geom_tile(color = "white") +
  geom_text(aes(label = round(distance, 1)), size = 4) +
  scale_fill_gradient(low = "white", high = "steelblue") +
  theme_minimal(base_size = 14) +
  labs(title = "Language distance matrix (lexical + syntactic)", x = "", y = "")

ggsave("../figs/fig_distance_heatmap.png", p_heat, width = 7, height = 6, dpi = 300)

# ==========================
# 4. PCA
# ==========================
pca <- PCA(X, graph = FALSE, scale.unit = FALSE)

p_pca <- fviz_pca_ind(
  pca, geom.ind = "point",
  habillage = df$language,
  addEllipses = TRUE, ellipse.level = 0.68,
  palette = "Dark2",
  title = "PCA: lexical + syntactic features"
) + theme_minimal(base_size = 13)

ggsave("../figs/fig_pca.png", p_pca, width = 8, height = 6, dpi = 300)

# ==========================
# 5. MDS
# ==========================
mds <- cmdscale(D_lang, k = 2, eig = TRUE)
mds_df <- data.frame(
  language = rownames(mds$points),
  MDS1 = mds$points[,1],
  MDS2 = mds$points[,2]
)

p_mds <- ggplot(mds_df, aes(MDS1, MDS2, label = language, color = language)) +
  geom_point(size = 5) +
  geom_text_repel(size = 5, show.legend = FALSE) +
  theme_minimal(base_size = 14) +
  labs(title = "MDS: language distances")

ggsave("../figs/fig_mds_language.png", p_mds, width = 7, height = 5, dpi = 300)

# ==========================
# 6. 聚类树
# ==========================
hc <- hclust(D_lang, method = "ward.D2")

png("../figs/fig_dendrogram.png", width = 900, height = 600, res = 150)
plot(hc, main = "Language clustering (Ward.D2)", xlab = "", sub = "")
dev.off()

# ==========================
# 7. 轮廓系数（修正版）
# ==========================
max_k <- min(4, nlevels(factor(rownames(lang_mean))) - 1)
sil_df <- data.frame(k = 2:max_k, silhouette = NA)
for (k in 2:max_k) {
  sil <- silhouette(cutree(hc, k), D_lang)
  sil_df$silhouette[k-1] <- if (is.matrix(sil)) mean(sil[, 3]) else mean(sil)
}

p_sil <- ggplot(sil_df, aes(k, silhouette)) +
  geom_line(color = "steelblue", linewidth = 1) +
  geom_point(size = 3, color = "steelblue") +
  theme_minimal(base_size = 14) +
  labs(title = "Average silhouette by k", x = "k", y = "Silhouette")

ggsave("../figs/fig_silhouette.png", p_sil, width = 6, height = 5, dpi = 300)

# ==========================
# 8. Mantel 散点图
# ==========================
E_norm <- E / sqrt(rowSums(E^2))
cos_sim <- E_norm %*% t(E_norm)
D_sem <- as.dist(1 - cos_sim)

D_syn_mat <- as.matrix(D)
D_sem_mat <- as.matrix(D_sem)

set.seed(42)
n <- nrow(D_syn_mat)
idx <- sample(which(lower.tri(D_syn_mat)), 5000)
mantel_df <- data.frame(
  syn = D_syn_mat[idx],
  sem = D_sem_mat[idx]
)

p_mantel <- ggplot(mantel_df, aes(syn, sem)) +
  geom_point(alpha = 0.2, size = 0.8, color = "steelblue") +
  geom_smooth(method = "lm", color = "red", se = TRUE) +
  theme_minimal(base_size = 14) +
  labs(title = "Mantel: lexical-syntactic vs semantic distance",
       x = "Lexical + syntactic distance",
       y = "Semantic distance (cosine)")

ggsave("../figs/fig_mantel_scatter.png", p_mantel, width = 7, height = 5, dpi = 300)

# ==========================
# 9. 混合模型森林图
# ==========================
if (file.exists("../mixed_model_results.csv")) {
  mm <- read_csv("../mixed_model_results.csv", show_col_types = FALSE) %>%
    filter(effect == "fixed", str_detect(term, "^language")) %>%
    mutate(
      lang = str_remove(term, "^language"),
      feature = factor(feature, levels = unique(feature))
    )

  p_forest <- ggplot(mm, aes(x = estimate, y = lang, color = feature)) +
    geom_vline(xintercept = 0, linetype = "dashed", color = "grey50") +
    geom_pointrange(aes(xmin = conf.low, xmax = conf.high),
                    position = position_dodge(width = 0.5)) +
    facet_wrap(~ feature, scales = "free_x") +
    theme_minimal(base_size = 12) +
    labs(title = "Mixed model: language fixed effects",
         x = "Estimate (95% CI)", y = "") +
    theme(legend.position = "none")

  ggsave("../figs/fig_mixed_forest.png", p_forest, width = 10, height = 7, dpi = 300)
}

cat("All figures saved to ../figs/\n")