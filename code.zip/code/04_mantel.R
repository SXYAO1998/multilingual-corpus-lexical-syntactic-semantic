library(arrow)
library(tidyverse)
library(vegan)

df <- read_parquet("../analysis_df.parquet")
E  <- readRDS("../embed_matrix.rds")

meta_cols <- c("doc_id","language","lang_code","stage","concept","query",
               "n_chars","n_sections","pageid","revid")
feat_cols <- setdiff(names(df), meta_cols)

E <- E[df$doc_id, , drop = FALSE]

X <- df %>%
  select(all_of(feat_cols)) %>%
  mutate(across(everything(), ~ replace_na(., 0))) %>%
  scale()
D_syn <- dist(X, method = "euclidean")

# 手动计算余弦距离，不用 proxy
E_norm <- E / sqrt(rowSums(E^2))
cos_sim <- E_norm %*% t(E_norm)
D_sem <- as.dist(1 - cos_sim)

set.seed(42)
cat("===== Mantel: 词汇+句法 vs 语义 =====\n")
print(mantel(D_syn, D_sem, method = "spearman", permutations = 999))

lang <- df$language
same <- outer(lang, lang, `==`)
diag(same) <- NA

Ds <- as.matrix(D_syn); Dm <- as.matrix(D_sem)

cat("\n===== 语言内 Mantel =====\n")
set.seed(42)
print(mantel(Ds[same], Dm[same], method = "spearman", permutations = 999))

cat("\n===== 语言间 Mantel =====\n")
set.seed(42)
print(mantel(Ds[!same], Dm[!same], method = "spearman", permutations = 999))