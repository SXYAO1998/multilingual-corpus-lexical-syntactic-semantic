library(arrow)
library(tidyverse)
library(vegan)

df <- read_parquet("../analysis_df.parquet") %>%
  mutate(log_chars = log(n_chars))

meta_cols <- c("doc_id","language","lang_code","stage","concept","query",
               "n_chars","n_sections","pageid","revid","log_chars")
feat_cols <- setdiff(names(df), meta_cols)

X <- df %>%
  select(all_of(feat_cols)) %>%
  mutate(across(everything(), ~ replace_na(., 0))) %>%
  scale()

D <- dist(X, method = "euclidean")

set.seed(42)

cat("===== by = terms =====\n")
p1 <- adonis2(D ~ language + log_chars + stage,
              data = df, permutations = 999, by = "terms")
print(p1)
flush.console()

cat("\n===== by = margin =====\n")
set.seed(42)
p2 <- adonis2(D ~ language + log_chars + stage,
              data = df, permutations = 999, by = "margin")
print(p2)
flush.console()

cat("\n===== language only =====\n")
set.seed(42)
p3 <- adonis2(D ~ language, data = df, permutations = 999)
print(p3)
flush.console()

cat("\n===== log_chars only =====\n")
set.seed(42)
p4 <- adonis2(D ~ log_chars, data = df, permutations = 999)
print(p4)
flush.console()