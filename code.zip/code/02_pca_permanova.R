library(arrow)
library(tidyverse)
library(vegan)
library(FactoMineR)
library(factoextra)

df <- read_parquet("../analysis_df.parquet")
df <- df %>% mutate(log_chars = log(n_chars))

meta_cols <- c("doc_id","language","lang_code","stage","concept","query",
               "n_chars","n_sections","pageid","revid","log_chars")
feat_cols <- setdiff(names(df), meta_cols)

cat("number of feature columns:", length(feat_cols), "\n")
cat("first 10 feature columns:\n")
print(head(feat_cols, 10))

X <- df %>%
  select(all_of(feat_cols)) %>%
  mutate(across(everything(), ~ replace_na(., 0))) %>%
  scale()

D <- dist(X, method = "euclidean")

set.seed(42)
perm <- adonis2(
  D ~ language + log_chars + stage,
  data = df,
  permutations = 999
)
cat("\n===== PERMANOVA =====\n")
print(perm)

pca <- PCA(X, graph = FALSE, scale.unit = FALSE)
cat("\n===== PCA 前 5 维解释率 =====\n")
print(round(pca$eig[1:5, 2], 2))

p <- fviz_pca_ind(pca, geom.ind = "point",
                  habillage = df$language,
                  addEllipses = TRUE, ellipse.level = 0.68,
                  palette = "Dark2",
                  title = "PCA: 词汇 + 句法特征") +
  theme_minimal(base_size = 13)
ggsave("../fig_pca.png", p, width = 8, height = 6, dpi = 300)
cat("\nsaved: fig_pca.png\n")