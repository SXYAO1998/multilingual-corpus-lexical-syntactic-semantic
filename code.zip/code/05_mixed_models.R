library(arrow)
library(tidyverse)
library(lme4)
library(lmerTest)
library(broom.mixed)

df <- read_parquet("../analysis_df.parquet") %>%
  mutate(
    log_chars = log(n_chars),
    language = factor(language),
    stage = factor(stage),
    query = factor(query)
  )

cat("stage levels:", nlevels(df$stage), "\n")
cat("language levels:", nlevels(df$language), "\n")
cat("query levels:", nlevels(df$query), "\n")
print(table(df$stage))
print(table(df$language))

targets <- c("ttr", "mtld", "entropy", "hapax_ratio",
             "mean_dep_distance", "mean_tree_height")

res <- list()
for (v in targets) {
  if (!v %in% names(df)) next
  f <- as.formula(paste(v, "~ language + log_chars + stage + (1|query)"))
  m <- lmer(f, data = df, REML = TRUE)
  res[[v]] <- tidy(m, effects = "fixed", conf.int = TRUE)
  cat("done:", v, "\n")
}

all_res <- bind_rows(res, .id = "feature")
write_csv(all_res, "../mixed_model_results.csv")

cat("\n===== 混合模型固定效应 (前 40 行) =====\n")
print(all_res, n = 40)