# -*- coding: utf-8 -*-
"""
Feature extraction for multilingual comparison study.

Input:
    ../data/corpus_meta_v6.csv
    ../data/corpus_text_v6.csv

Output:
    ../data/features_vocab.parquet
    ../data/features_syntax.parquet
    ../data/features_embed.parquet

Dependencies:
    pip install stanza transformers torch sentence-transformers pandas pyarrow tqdm
"""

import os
import re
import math
import time
import numpy as np
import pandas as pd
from collections import Counter
from tqdm import tqdm
import stanza
from sentence_transformers import SentenceTransformer
import torch

# ==========================
# Configuration
# ==========================
META_CSV = "../data/corpus_meta_v6.csv"
TEXT_CSV = "../data/corpus_text_v6.csv"

MAX_TOKENS = 2000
LANGS_UD = {"en": "en", "zh": "zh-hans", "es": "es", "fr": "fr", "de": "de"}

OUT_VOCAB = "../data/features_vocab.parquet"
OUT_SYNTAX = "../data/features_syntax.parquet"
OUT_EMBED = "../data/features_embed.parquet"

# ==========================
# Load corpus
# ==========================
df = pd.read_csv(META_CSV).merge(pd.read_csv(TEXT_CSV), on="doc_id")
print(f"docs: {len(df)}")
print(df.groupby("language").size())

# ==========================
# Initialize Stanza + LaBSE
# ==========================
use_gpu = torch.cuda.is_available()
print("GPU:", use_gpu)

nlp = {
    code: stanza.Pipeline(
        lang=ud,
        processors="tokenize,pos,lemma,depparse",
        use_gpu=use_gpu,
        verbose=False,
    )
    for code, ud in LANGS_UD.items()
}

labse = SentenceTransformer("sentence-transformers/LaBSE")
if use_gpu:
    labse = labse.cuda()

# ==========================
# Lexical metrics
# ==========================
def ttr(tokens):
    return len(set(tokens)) / len(tokens) if tokens else 0.0

def mtld(tokens, thresh=0.72):
    def one_dir(toks):
        factors, types, count = 0, set(), 0
        for t in toks:
            count += 1
            types.add(t)
            if len(types) / count <= thresh:
                factors += 1
                types = set()
                count = 0
        if count > 0:
            factors += (1 - len(types) / count) / (1 - thresh)
        return max(factors, 1)
    f, b = one_dir(tokens), one_dir(list(reversed(tokens)))
    return len(tokens) / ((f + b) / 2) if (f + b) > 0 else 0.0

def entropy(tokens):
    if not tokens:
        return 0.0
    c = Counter(tokens)
    n = sum(c.values())
    return -sum((v / n) * math.log(v / n) for v in c.values())

def hapax_ratio(tokens):
    if not tokens:
        return 0.0
    c = Counter(tokens)
    return sum(1 for v in c.values() if v == 1) / len(c)

# ==========================
# Syntactic metrics
# ==========================
def mean_dep_distance(doc):
    d = [abs(w.id - w.head) for s in doc.sentences
         for w in s.words if w.head > 0]
    return float(np.mean(d)) if d else 0.0

def mean_tree_height(doc):
    heights = []
    for s in doc.sentences:
        if not s.words:
            continue
        def depth(w):
            k, cur = 0, w
            while cur.head > 0 and k < 200:
                cur = s.words[cur.head - 1]
                k += 1
            return k
        heights.append(max(depth(w) for w in s.words))
    return float(np.mean(heights)) if heights else 0.0

def pos_dist(doc):
    c = Counter(w.upos or "X" for s in doc.sentences for w in s.words)
    n = sum(c.values())
    return {f"pos_{k}": v / n for k, v in c.items()} if n else {}

def dep_dist(doc):
    c = Counter(w.deprel or "dep" for s in doc.sentences for w in s.words)
    n = sum(c.values())
    return {f"dep_{k}": v / n for k, v in c.items()} if n else {}

# ==========================
# Extraction loop
# ==========================
vocab_rows, syntax_rows, embed_rows = [], [], []
t0 = time.time()

for _, r in tqdm(df.iterrows(), total=len(df), desc="extract"):
    doc_id, code, text = r["doc_id"], r["lang_code"], str(r["text"])

    truncated = text[:MAX_TOKENS * 10]

    try:
        doc = nlp[code](truncated)
    except Exception as e:
        print(f"[skip] {doc_id}: {e}")
        continue

    tokens = [w.text.lower() for s in doc.sentences
              for w in s.words if w.upos != "PUNCT"][:MAX_TOKENS]
    if len(tokens) < 50:
        print(f"[skip] {doc_id}: tokens < 50")
        continue

    # Lexical
    vocab_rows.append({
        "doc_id": doc_id,
        "n_tokens": len(tokens),
        "n_types": len(set(tokens)),
        "ttr": ttr(tokens),
        "mtld": mtld(tokens),
        "entropy": entropy(tokens),
        "hapax_ratio": hapax_ratio(tokens),
        "mean_word_len": float(np.mean([len(t) for t in tokens])),
    })

    # Syntactic
    syntax_rows.append({
        "doc_id": doc_id,
        "mean_dep_distance": mean_dep_distance(doc),
        "mean_tree_height": mean_tree_height(doc),
        "n_sentences": len(doc.sentences),
        "mean_sent_len": len(tokens) / max(len(doc.sentences), 1),
        **pos_dist(doc),
        **dep_dist(doc),
    })

    # Semantic (LaBSE)
    sents = [s.text for s in doc.sentences][:20]
    if sents:
        emb = labse.encode(sents, normalize_embeddings=True,
                           show_progress_bar=False, batch_size=16)
        vec = emb.mean(axis=0).astype("float32")
    else:
        vec = np.zeros(768, dtype="float32")

    embed_rows.append({"doc_id": doc_id,
                       **{f"e{i}": float(v) for i, v in enumerate(vec)}})

# ==========================
# Save
# ==========================
pd.DataFrame(vocab_rows).to_parquet(OUT_VOCAB, index=False)
pd.DataFrame(syntax_rows).to_parquet(OUT_SYNTAX, index=False)
pd.DataFrame(embed_rows).to_parquet(OUT_EMBED, index=False)

print(f"\nDone in {(time.time() - t0) / 60:.1f} min")
print(f"saved: {OUT_VOCAB}  ({len(vocab_rows)} rows)")
print(f"saved: {OUT_SYNTAX} ({len(syntax_rows)} rows)")
print(f"saved: {OUT_EMBED}  ({len(embed_rows)} rows)")