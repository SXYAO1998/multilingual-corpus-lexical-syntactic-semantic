library(arrow)
library(tidyverse)

meta   <- read_csv("../corpus_meta_v6.csv", show_col_types = FALSE)
vocab  <- read_parquet("../features_vocab_clean.parquet")
syntax <- read_parquet("../features_syntax_clean.parquet")
embed  <- read_parquet("../features_embed.parquet")

df <- meta %>%
  select(doc_id, language, lang_code, stage, concept, query, n_chars) %>%
  inner_join(vocab,  by = "doc_id") %>%
  inner_join(syntax, by = "doc_id")

cat("merged rows:", nrow(df), "\n")
print(table(df$language, df$stage))

write_parquet(df, "../analysis_df.parquet")

E <- embed %>% column_to_rownames("doc_id") %>% as.matrix()
saveRDS(E, "../embed_matrix.rds")

cat("done: analysis_df.parquet and embed_matrix.rds written\n")