library(arrow)
library(tidyverse)
library(vegan)
library(cluster)
library(factoextra)
library(ggrepel)

df <- read_parquet("../analysis_df.parquet") %>%
  mutate(log_chars = log(n_chars))

meta_cols <- c("doc_id","language","lang_code","stage","concept","query",
               "n_chars","n_sections","pageid","revid","log_chars")
feat_cols <- setdiff(names(df), meta_cols)

cat("feature columns:", length(feat_cols), "\n")

# 文档级 X
X <- df %>%
  select(all_of(feat_cols)) %>%
  mutate(across(everything(), ~ replace_na(., 0))) %>%
  scale()

# 语言级平均
lang_mean <- df %>%
  group_by(language) %>%
  summarise(across(all_of(feat_cols), mean, na.rm = TRUE)) %>%
  column_to_rownames("language") %>%
  scale()

D_lang <- dist(lang_mean, method = "euclidean")

cat("\n===== 语言间距离矩阵 =====\n")
print(round(as.matrix(D_lang), 2))

# MDS
mds <- cmdscale(D_lang, k = 2, eig = TRUE)
mds_df <- data.frame(
  language = rownames(mds$points),
  MDS1 = mds$points[,1],
  MDS2 = mds$points[,2]
)
cat("\n===== MDS 前两轴特征值占比 =====\n")
print(round(mds$eig[1:2] / sum(mds$eig[mds$eig > 0]) * 100, 2))

p_mds <- ggplot(mds_df, aes(MDS1, MDS2, label = language, color = language)) +
  geom_point(size = 4) +
  geom_text_repel(size = 5, show.legend = FALSE) +
  theme_minimal(base_size = 14) +
  labs(title = "MDS: 语言间词汇+句法距离")
ggsave("../fig_mds_language.png", p_mds, width = 7, height = 5, dpi = 300)

# 层次聚类
hc <- hclust(D_lang, method = "ward.D2")
cat("\n===== 层次聚类合并顺序 =====\n")
print(round(hc$height, 2))

png("../fig_dendrogram.png", width = 800, height = 600, res = 120)
plot(hc, main = "语言聚类树 (Ward.D2)", xlab = "", sub = "")
dev.off()

# 轮廓系数
cat("\n===== 轮廓系数 (k=2..4) =====\n")
for (k in 2:4) {
  sil <- mean(silhouette(cutree(hc, k), D_lang)[, 3])
  cat("k =", k, "  avg silhouette =", round(sil, 3), "\n")
}

cat("\nsaved: fig_mds_language.png, fig_dendrogram.png\n")